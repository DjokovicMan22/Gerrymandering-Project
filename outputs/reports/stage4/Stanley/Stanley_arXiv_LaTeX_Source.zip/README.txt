Stanley — editable LaTeX research manuscript.
Contents include the editable TeX manuscript and every referenced plot.
Verify human contributions, permissions, licensing, references, and arXiv eligibility before submission.
