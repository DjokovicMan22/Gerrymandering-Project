AI-assisted format demonstration only; NOT reviewed, endorsed, or submitted to arXiv.
Contents include the editable TeX manuscript and every referenced plot.
Verify human contributions, permissions, licensing, references, and arXiv eligibility before submission.
